## Time Series Forecasting with Deep Learning /LSTM Part 1
Jupyter Notebook and data files for the tutorial Time Series Forecasting with Deep Learning/LSTM - PI.

The tutorial video is available at : https://youtu.be/d_qX2V9iBeQ 


[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/d_qX2V9iBeQ/0.jpg)](https://www.youtube.com/watch?v=d_qX2V9iBeQ)

